
//SLIDERS


$(".top-slider").slick({
  nextArrow: '<div class="slider-b slider-b-right"><i class="fa fa-angle-right car-arrow-left car-arrow"></i></div>',
  prevArrow: '<div class="slider-b slider-b-left"><i class="fa fa-angle-left car-arrow-right car-arrow"></i></div>',
  dots: false
});



// TABS
/*
$(document).ready(function(){
  
  $('.tab-content>.tabs-item:not(":first-of-type")').hide();   
   $('.tab-menu li:first-of-type').find(':first').width('100%');  
 
  $('.tab-menu li').each(function(i){ 
    $(this).attr('data-tab', 'tab'+i);
  });
  
  $('.tab-content .tabs-item').each(function(i){  
    $(this).attr('data-tab', 'tab'+i);
  });
  
  $('.tab-menu li').on('click', function(){  
    
    var dataTab = $(this).data('tab'); 
    var getWrapper = $(this).closest('.tab-wrapper'); 
    
    getWrapper.find('.tab-menu li').removeClass('active'); 
    $(this).addClass('active'); 

    getWrapper.find('.tab-content>.tabs-item').hide(); 
    getWrapper.find('.tab-content>.tabs-item[data-tab='+dataTab+']').show();
    
  });
});

*/



// MAGNIFIC

$('.popup-form').magnificPopup();

$('.gallery').magnificPopup({
  type: 'image',
  gallery: {
      enabled: true,
      navigateByImgClick: true,
      preload: [0,1] // Will preload 0 - before current, and 1 after the current image
  }
});


/*

// FOR LANDING


$("#form").submit(function() {
  $.ajax({
    type: "POST",
    url: "mail.php",
    data: $(this).serialize()
  }).done(function() {
    $(this).find("input").val("");
    alert("Спасибо за заявку! Скоро мы с вами свяжемся.");
    
    $("#form").trigger("reset");
    $.magnificPopup.close();
  });
  return false;
});
*/

/*

// SCROLL ID

$(document).ready(function(){
  $("#menu").on("click","a", function (event) {
    event.preventDefault();

    var id  = $(this).attr('href'),
    top = $(id).offset().top -80;

    var width = document.body.clientWidth;
    if (width <= 600) {$(".menu__container").slideToggle("fast");}
    
    $('body,html').animate({scrollTop: top}, 1500)
  });
});

*/


/*

// FIXED MENU

window.onscroll = function() {
  var scrolled = window.pageYOffset || document.documentElement.scrollTop;
  var element = document.getElementById('menu');
  var lastScroll = 0;

  if (scrolled > 100){
    element.style.position = "fixed";
  } else {
    element.style.position = "relative"; 
  }
};
*/