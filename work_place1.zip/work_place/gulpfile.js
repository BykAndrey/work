// переменные 

var gulp = require("gulp");
var postcss = require("gulp-postcss");
var rename = require("gulp-rename");
var precss = require('precss');
var imagemin = require('gulp-imagemin');
var pngquant = require('imagemin-pngquant');
var browserSync = require('browser-sync');
var autoprefixer = require("autoprefixer");
var cssnano = require("cssnano");


// browser - reload 

gulp.task('browser-sync',['css'], function() {
	browserSync({
		server: {
			baseDir: 'app'
		},
		notify: false
	});
});

// postcss

gulp.task("css", function(){
	var processors = [
			precss(),
			autoprefixer({ browsers: ["last 5 version"] }),

		];
	
	return gulp.src("app/postcss/*.css")
		.pipe(postcss(processors))
		//.pipe(rename("main.css"))
		.pipe(gulp.dest("app/css/"));
});


// imagemin

gulp.task('img', function() {
	return gulp.src('app/img/**/*')
	.pipe(imagemin({
		interlaced: true,
		progressive: true,
		une: [pngquant()]
	}))
	.pipe(gulp.dest('dist/img')); 
});


// watch!

gulp.task('watch', ['browser-sync', 'css'], function(){
	gulp.watch('app/postcss/*.css', ['css']).on('change', browserSync.reload);;
	gulp.watch('app/*.html').on('change', browserSync.reload);
	gulp.watch('app/js/*.js').on('change', browserSync.reload);
});

gulp.task('default', ['watch']);


